#!/usr/bin/python3
# -*- coding: utf-8 -*-


def handle_safe_mode(username,context):
    #You can restore any feature or file to default
    pass
